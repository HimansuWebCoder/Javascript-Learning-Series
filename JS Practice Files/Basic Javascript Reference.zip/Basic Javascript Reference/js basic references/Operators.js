// ? Arithmetic:-
// Addition(+) 
// Subtraction(-)
// Multiplication(*)
// Exponentiation(**)
// Divison(/)
// Remainder(%)
// Pre increment(++)
// Post increment(++)
// Pre decrement(--)
// Post decrement(--)

// ? Assignment:-
// =
// +=
// -=
// *=
// /=
// %=
// :


// ? String:-
// +
// +=

// ? Comparison:-
// equal to ==
// equal value & type ===
// not equal !=
// not equal value or type !==
// greater than >
// less than <
// greater  or equal to >=
// less  or equal to <=

// ? Conditional(Ternary):-
// (condition) ? x : y 

// ? Logical:-
// AND (&&)
// OR (||)
// NOT (!)

// ? typeof :-
// ? delete :-
// ? spread(...) :- 
// ? in :-
// ? instanceof:-

// precedence 

