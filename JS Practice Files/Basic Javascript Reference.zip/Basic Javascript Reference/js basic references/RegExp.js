//* modifiers
// g
// i 
// m 

//* groups
// [abc]
// [^abc]
// [0-9]
// [^0-9]
// (x|y)

//* metacharacters
// \w 
// \W 
// \d 
// \D 

// learn after learn more after learn advance javascript