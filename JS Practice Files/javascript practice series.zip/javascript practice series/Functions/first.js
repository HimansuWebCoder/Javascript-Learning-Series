// first.js
const name = "Himansu";
function greeting() {
  alert(`Hello ${name}: welcome to our company.`);
}
