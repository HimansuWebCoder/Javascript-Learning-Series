//? Strings the basics
//* Creating a string
// const string = "The revolution will not be televised.";
// string;

// const fruits = "fruits are the life of a positive heart.";
// fruits;

// const children = "Childrens are the god's child.";
// children;

// const badString1 = This is a test; //wrong
// const badString2 = 'This is a test; //wrong
// const badString3 = This is a test'; //wrong

//* work if :-
// const string = "I am a programmer";
// const badString = string;
// badString;

// const flower = "I am a flower tagar";
// const flowerSpeech = flower;
// flowerSpeech;

// const tech = " The tech is more powerful in future";
// const newTech = tech;
// newTech;

// const names = "the name is the powerful words that exist for identity.";
// const newNames = names;
// newNames;

//* Single quotes ('') vs. Double quotes ("")
// const sgl = 'Single quotes.';
// const dbl = "Double quote";
// sgl;
// dbl;

// const himansu = 'Hello I am himansu';
// himansu;
// const rinky = "hello I am rinky";
// rinky;

// const badQuotes = 'What on earth?";

// const sglDbl = 'Would you eat a "fish supper"?';
// const dblSgl = "I'm feeling blue.";
// sglDbl;
// dblSgl;

// const talk = 'Hey how are you doing "working"?';
// const reply = "Yes I'm doing.";
// talk;
// reply;

// const bigmouth = 'I've got no right to take my place..'; // wrong

// *Escaping characters in a string
// const bigmouth = 'I\'ve got no right to take my place..';
// bigmouth;

// const speech = 'I\'ve got no right to take my place..';
// speech;

// const ask = 'Hii! I\'m himansu.';
// ask;

// *Concatenating Strings
// const greeting =`Hello`; // it is a string like normal string Template literal

// const one = "Hello, ";
// const two = "how are you?";
// const joined = `${one}${two}`;
// joined;

// const fruits = "Mango";
// const flower = "Gendu";
// const joinedthis = `${fruits} ${flower}`;
// joinedthis;

// const boy = "Hello mahindra!";
// const car = "Hii!";
// const mixed = `${boy} ${car}`;
// mixed;

//* Concatenation in context
// const button = document.querySelector("button");

// function greet() {
//   const name = prompt("What is your name?");
//   alert(`Hello ${name}, nice to see you!`);
// }
// button.addEventListener("click", greet);

// const button = document.querySelector("button");

// function call() {
//   const name = prompt("What is your job?");
//   alert(`is this ${name}, enjoyable for you!`);
// }
// button.addEventListener("mouseover", call);

// *Concatenation using "+"
// const greeting = "Hello";
// const name = "Himansu";
// console.log(greeting + " " + name);

// const tag = "#Himansu";
// const viral = "#Himansu Programmer";
// console.log(tag + " " + viral);

// const flower = "Tagar";
// const Vegetable = "Brinjal";
// console.log(flower + " " + Vegetable);

//* Using Template literal
// const greeting = "Hello";
// const name = "Himansu";
// console.log(`${greeting},${name}`);

// const ramesh = "Hello Himansu";
// const himansu = "Hii!";
// console.log(`${ramesh} ${himansu}`);

// const lulu = "Hii friends!";
// const friends = "Hii!";
// console.log(`${lulu} ${friends}`);

//* Numbers vs. Strings
// const name = "Front ";
// const number = 232;
// console.log(`${name}${number}`);

// const flower = "Tagar";
// const fnumber = "100";
// console.log(`${flower} ${fnumber}`);

//*Number(). string to number convert
// const myString = "123";
// const myNum = Number(myString);
// console.log(typeof myNum);

// const myNumber = "298";
// const mynewNumber = Number(myNumber);
// console.log(typeof mynewNumber);

//*toString().
// const myNum2 = 123;
// const myString2 = myNum2.toString();
// console.log(typeof myString2);

// const myNum3 = 287;
// const myString3 = myNum3.toString();
// console.log(typeof myString3);

// const myNum4 = 1200;
// const myString4 = myNum4.toString();
// console.log(typeof myString4)

//* Including expressions in strings

// const song = "Fight the Youth";
// const score = 9;
// const highestScore = 10;
// const output = `I like the song ${song}. I gave it a score of ${(score / highestScore)* 100}%.`;
// output;

// const bird = "Fly the bird";
// const birdscore = 10;
// const highbirdScore = 20;
// const outputbird = `I like the bird ${bird}. I gave it a score of ${(birdscore / highbirdScore)* 100}%.`;
// outputbird

// * Multiline Strings
// const output = `I like the song. I gave it a score of 90%.`;
// output;

//* using (\n)
// const output = "I like the song. \nI gave it a score of 90%.";
// output;
// console.log(output);

// const myoutput = "I love do programming. \nI gave my 201% to it for learning and building.";
// myoutput;

//* Useful String Methods
//* Strings as Objects
// const string = 'This is my string';

//* Finding the lenght of a string
// const browserType = 'mozilla';
// console.log(browserType.length);

// const bird = "peacock";
// console.log(bird.length);

// const flower = "Haragaura";
// console.log(flower.length);

// const vehicle = "Tata maruti"; //* this include empty space also count this js
// console.log(vehicle.length)

// const ourHouse = "Our house is very bearutiful inside not outside";
// console.log(ourHouse.length)

//* Retrieving a specific string character
// const browserType = 'mozilla';
// console.log(browserType[0]);
// console.log(browserType[browserType.length-1]);

// const bird = "Parrot";
// console.log(bird[0]);
// console.log(bird[1]);
// console.log(bird[2]);
// console.log(bird[3]);
// console.log(bird[4]);
// console.log(bird[5]);
// console.log(bird[bird.length-1]);
// console.log(bird[bird.length-2]);
// console.log(bird[bird.length-3]);
// console.log(bird[bird.length-4]);
// console.log(bird[bird.length-5]);
// console.log(bird[bird.length-6])

//* Testing if a string contains a substring
// *includes()
// const browserType = 'mozilla';
// if (browserType.includes('zilla')) {
// 	console.log('Found zilla!');
// } else {
// 	console.log('No zilla here!');
// }

// const flower = "flower is the beautiful creation by God.";
// flower.includes("is");
// console.log(flower.includes("is"))
// console.log(flower.includes("flower"));
// console.log(flower.includes("no"));
// console.log(flower.includes("himansu"));
// console.log(flower.includes("god"));
// console.log(flower.includes("God"));

// const sentence = 'The quick brown fox jumps over the lazy dog.';
// const word = 'fox';
// console.log(`The word "${word}" ${sentence.includes(word) ? 'is' : 'is not'} in the sentence`);

//*startsWith()
// const browserType = 'mozilla';

// if (browserType.startsWith('zilla')) {
// 	console.log('Found zilla!');
// } else {
// 	console.log('No zilla here!');
// }

// const learning = "Learning is the beautiful and amazing journey in our life.";
// console.log(learning.startsWith("Learning"));
// console.log(learning.startsWith("is"));
// console.log(learning.startsWith("Learning is"));
// console.log(learning.startsWith("amazing"));

// const browserType = 'mozilla';

// if (browserType.endsWith('zilla')) {
// 	console.log('Found zilla!');
// } else {
// 	console.log('No zilla here!');
// }

// const programming = "Programming is the only thing when start you starts to how to think.";
// console.log(programming.endsWith("think"))
// console.log(programming.endsWith("think."));

//* Finding the position of a substring in a string
//* indexOf()
// const tagline = 'MDN - Resources for developer, by developers';
// console.log(tagline.indexOf('developers'))
// console.log(tagline.indexOf('x'));
// because x is not present in string

// const myName = "Himansu is a programmer";
// console.log(myName.indexOf("a"));
// console.log(myName.indexOf("is"));
// console.log(myName.indexOf("programmer"));
// console.log(myName.indexOf("x"));
// console.log(myName.indexOf("HIMANSU"));

// const tagline = "MDN - Resources for developer, by developers";
// const firstOccurrence = tagline.indexOf("developers");
// const secondOccurrence = tagline.indexOf("developers", firstOccurrence + 1);

// console.log(firstOccurrence);
// console.log(secondOccurrence);

// const school = "Our kamarda school is my past childhood study place.";
// const firstSchool = school.indexOf("kamarda");
// const secondSchool = school.indexOf("study", firstSchool);

// console.log(firstSchool);
// console.log(secondSchool);

//* Extracting a substring from a string
//* slice()
// const browserType = 'mozilla';
// console.log(browserType.slice(1,4));
// first include but not last
// console.log(browserType.slice(2));

// const animal = "Elephant";
// console.log(animal.slice(0,1));
// console.log(animal.slice(0,4));
// console.log(animal.slice(2));
// console.log(animal.slice(0,8));

//* Changing case
//* toUpperCase()
//* toLowerCase()
// const radData = 'My NaMe Is MuD';
// console.log(radData.toLowerCase());
// console.log(radData.toUpperCase());

// const city = "Dhenkanal";
// console.log(city.toUpperCase());
// console.log(city.toLowerCase());

//* Updating parts of a string
//* replace()
// const browserType = 'mozilla';
// const updated = browserType.replace('moz', 'van');

// console.log(updated);
// console.log(browserType);

// const bird = "Peacock is my fav bird";
// const birdUpdate = bird.replace('Peacock', "Parrot");
// console.log(birdUpdate);

// const vehicle = "Maruti is my fav car";
// const newUpdateCar = vehicle.replace("Maruti", "TATA");
// console.log(newUpdateCar);

// const greet = "Hello himansu how are you?";
// const updateGreet = greet.replace("him", "Aka");
// console.log(updateGreet);

// let browserType = 'mozilla';
// browserType = browserType.replace('moz', 'van');

// console.log(browserType);

//*replaceAll()
// let quote = "To be or not to be";
// quote = quote.replaceAll("be", "code");

// console.log(quote);

// let greet = "Hello guys All, how are you All!";
// greet = greet.replaceAll("All", "makka");

// console.log(greet)

//* Active Learning Examples
//* Filtering greeting messages
//*Fixing capitalization
//*Making new strings from old parts
//* All above in MDN DOCS
//* Read and see those
