//* Fetch data from server
//* what is the problem here detail in MDN DOCs
//* The Fetch API
//* Fetching text content, in fetch-start.html and verse txt file .
 //* Serving your example from a server
 //* The can store
 //* The XMLHttpRequest API
 