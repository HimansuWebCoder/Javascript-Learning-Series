function myFruit() {
  console.log("Mango");
}
myFruit();

// myOrange() => {
// 	console.log("Orange")
// };
// myOrange()

//  (item) => item * 2 is arrow function equivalent of:
// function doubleItem(item) {
// 	return item * 2;
// }

let hima = (himansu) => himansu * 2;

function doublehimansu(a, b) {
  return a * b;
}
doublehimansu(2, 3);
console.log(doublehimansu(2, 3));

// let increment = 23;
// increment++;
// console.log(increment);
 let number = 4;
 number++;
 number;

 let increment = 12;
 number++;
 increment;
 