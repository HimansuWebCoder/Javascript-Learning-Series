// function checkGuess() {
//   alert("I am a placeholder");
// }
// checkGuess();

// function himansu() {
//   alert("I am a Programmer");
// }
// himansu();

// function rinky() {
//   prompt("What is your job");
// }
// rinky();

// console.log(2 + 2);
// console.log(2 - 2);
// console.log(10 * 10);
// console.log(10 / 2);
// console.log(12 + 12);
// console.log(12 - 12);
// console.log(23 * 2);
// console.log(120 / 12);

// const name = "Bingo";
// name;
// const hello = " says hello!";
// hello;
// const greeting = name + hello;
// greeting;

// const fruit = "mango";
// fruit;
// const flower = "Tagar";
// flower;
// const fruitsAndFlower = fruit + " " + flower;
// fruitsAndFlower;
// const fruitsAndFlower = `${fruit} ${flower}`;
// console.log(fruitsAndFlower);

// let name1 = "Bingo";
// name1 += " says hello!";
// console.log(name1)

//  or

// let name2 = "Bingo";
// name2 = name2 + " says hello!";
// console.log(name2)
//  or

//  let fruit = "mango";
//  fruit += " is a tasty food";
// console.log(fruit)

// 5 === 2 + 4; // false
// "Chris" === "Bob"; // false
// 5 === 2 + 3; // true
// 2 === "2"; // false; number versus string
// console.log(5 === 2 + 4);
// console.log("Chris" === "Bob");
// console.log(5 === 2 + 3);
// console.log(2 === "2");
// console.log(2 === 2 + 4);
// console.log(2 === 2);
// console.log(2 !== 2 + 4);
// console.log( 23 === 12);
// console.log(23 === 23);
// console.log(23 !== 24);
// console.log("Himansu" === "rinky");
// console.log("Himansu" === "Himansu");
// console.log("Himansu" === "himansu");
// console.log("Himansu" !== "Himansu");
// console.log("Himansu" !== "rinky");

// 5 !== 2 + 4; // true
// "Chris" !== "Bob"; // true
// 5 !== 2 + 3; // false
// 2 !== "2"; // true; number versus string
// console.log(5 !== 2 + 4);
// console.log("Chris" !== "Bob");
// console.log(5 !== 2 + 3);
// console.log(2 !== "2");
// console.log(10 !== 2 + 3);
// console.log( 10 !== 5 + 5);

// 6 < 10; // true
// 20 < 10; // false
// console.log(6 < 10);
// console.log(20 < 10);
// console.log(100 > 200);
// console.log(100 < 100);
// console.log(100 < 23);
// console.log(1000 > 100);

// 6 > 10; // false
// 20 > 10; // true
// console.log(6 > 10);
// console.log(20 > 10);

// const fruits = ["apples", "bananas", "cherries"];
// for (const fruit of fruits) {
//   console.log(fruit);
// }


// const fruits = ["apples", "banana", "lichi"];
// for (const fruit of fruits) {
//   console.log(fruit);
// }

// const fruitsNames = ["Apple", "Banana", "Lichi", "Mango"];
// for (const x of fruitsNames) {
//   console.log(x);
// }

// const flower = ["gendu", "malli", "tagar", "Haragaura"];
// for (const x of flower) {
//   console.log(x);
// }

// const $name = ["car", "bike", "cycle", "train", "aeroplane"];

// for (const car of $name) {
//   console.log(car);
// }

// but

// const $car = ["maruti", "suzuki", "bmw", "hyundai"];
// for (let i = 0; i < $car.length; i++) {
//   console.log($car[i]);
// }

// const vehicles = ["Maruti", "suzuki", "Hyundai", "Honda"];
// for (let i = 0; i < vehicles.length; i++) {
//   console.log(vehicles[i]);
// }

// const $flower = ["rose", "haragaura", "gendu", "tagar"];
// for (let i = 0; i < $flower.length; i++) {
//   console.log($flower[i]);
// }
// const _machine = ["dozer", "jcb", "bullet", "soldiertruck"];
// for (let i = 0; i < _machine.length; i++) {
//   console.log(_machine[i] + " " + " himansu");
// }
