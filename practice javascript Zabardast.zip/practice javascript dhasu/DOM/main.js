//* Manipulating documents (DOM)
//* The important parts of a web browser
//* The document object model
//* Active learning: Basic DOM manipulation
//* in dom-example.html file
//* Active learning: A dynamic shopping list
//* In shopping-list.html file