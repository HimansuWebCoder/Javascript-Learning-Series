//second.js
const name = "Rinky pvt.ltd";
function greeting() {
  alert(`Our company is called ${name}.`);
}
