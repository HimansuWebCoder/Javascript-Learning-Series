// const buttonA = document.querySelector("#button_A");
// const headingA = document.querySelector("#heading_A");

// buttonA.onclick = () => {
//   const name = prompt("what is your name?");
//   alert(`Hello ${name}, nice to see you!`);
//   headingA.textContent = `Welcome ${name}`;
// };

// Without a Variable

// const buttonB = document.querySelector("#button_B");
// const headingB = document.querySelector("#heading_B");

// buttonB.onclick = () => {
//   alert(`Hello ${prompt("what is your name?")}, nice to see you!`);
//   headingB.textContent = `Welcome ${prompt("what is your name?")}`;
// };

// Declaring a Variable
// let myName;
// let myAge;
// myName;
// myAge;
// scoobyDoo;

// Initializing a variable
// myName = "himansu";
// myAge = "19";
// myName;
// myAge;

// myCar = "maruti";
// myFriend = "Krishna";
// myCar;
// myFriend;

// fruit = "mango";
// flower = "haragaura";
// fruit;
// flower;

// sisterName = "papuni";
// brotherName = "Abhijeet";
// sisterName;
// brotherName;

// let myDog = "Tommy";
// myDog;

// let myCar = "Maruti";
// myCar;

// let myBag = "book";
// myBag;

// let myPencil = "Apsara";
// myPencil;

// let myFlower = "Tagar";
// myFlower;

// let myCat = "Tommy";
// myCat;

// let myBird = "parrot";
// myBird;

// let myCar = "TATA ponch";
// myCar;

// A note about var
// var myName;
// var myAge;
// var myCar;
// var book;
// var yourSister;
// var yourBrother;
// var greeting;
// var computer;
// var mouse;
// var type;

// var myName = "Himansu";
// var yourName = "susmita";
// var mycarName = "Maruti";
// var myBook = "Deep Work";
// var myFlower = "Mandar";

// function yourName() {
//   console.log("Himansu");
// }
// yourName();

// function myName() {
// 	console.log("Himansu");
// }
// myName();

// function ourHouse() {
// 	console.log("it is a beautiful house not outside inside also.");
// }
// ourHouse();

// var myName;

// var myName = 'Himansu';
// var myName = 'rinky';
// you can declare many times a variable with var
// but using let not
// let myName = 'Himansu';
// let myName = 'rinky'; // it is wrong

// let myBook = "Deep Work";
// let myBook = "The one thing"; //wrong

// let yourCar = "Maruti";
// let yourCar = "Hyundai"; // wrong

// you'd have to do this instead
// let myName = "Himansu";
// myName = "rinky";
// myName;

// let myBook = "Deep Work";
// myBook = "The one Thing";
// myBook;

// let yourCar = "Maruti";
// yourCar = "Hyundai";
// yourCar;

// let myFlower = "Haragaura";
// myFlower = "Tagar";
// myFlower;

// Updating a variable
// myName = 'rinky';
// myAge = 40;

// As aside on variable naming rules
// discuss details in MDN
// Good name examples
// age
// myAge
// init
// initialColor
// finalOutputValue
// audio1
// audio2

// Bad name examples
// 1
// a
// _12
// myage
// MYAGE
// var
// Document
// skjfndskjfndbdskjfb
// thisisareallylongvariablenameman

// Variable types

// Numbers
// let myAge = 19;
// myAge;

// let yourAge = 20;
// yourAge;

// let yourNumber = 3;
// yourNumber;

// let luckNumber = 9;
// yourNumber;

// let houseNumber = 99;
// houseNumber;

// Strings ('' or "")
// let dolphinGoodbye = 'So long and thanks for all the fish';
// dolphinGoodbye;

// Booleans
// let iAmAlive = true;
// iAmAlive;

// let himansu = true;
// himansu;

// let rinky = false;
// rinky;

// let papuni = false;
// papuni;

// let mani = true;
// mani;

// let mama = false;
// mama;

// let test = 6 > 3;
// test;

// let myScore = 20 > 10;
// myScore;

// let yourScore = 10 > 20;
// yourScore;

// let myNumber =   9 < 8;
// myNumber;

// let yourNumber = 10 > 9;
// yourNumber;

// Arrays
// let myNameArray = ["Himansu", "Rinky", "papuni"];
// let myNumberArray = [10, 15, 50];
// myNameArray;
// myNumberArray;

// let myFruits = ["Mango", "Orange", "Amla", "Kaju"];
// myFruits;

// * you can access each:
// console.log(myNameArray[0]);
// console.log(myNumberArray[0]);
// console.log(myFruits[0])
// console.log(myFruits[2]);

// let fruits = ["mango", "orange", "papaya", "lichi"];
// let cars = ["maruti", "hyundai", "tata", "mercedese"];
// let myNumber = [3, 2, 1, 4, 12, 54, 89];
// fruits;
// cars;
// myNumber;
// console.log(fruits[0]);
// console.log(fruits[1]);
// console.log(fruits[2]);
// console.log(fruits[3]);
// console.log(cars[0]);
// console.log(cars[1])
// console.log(cars[2])
// console.log(cars[3])
// console.log(myNumber[0])
// console.log(myNumber[1])
// console.log(myNumber[2])
// console.log(myNumber[3])
// console.log(myNumber[4])

// Objects
// let dog = {name : 'Tommy', greed : 'Dalmatian'};
// dog;
// console.log(dog.name);
// console.log(dog.greed);
// console.log(dog);

// let myDetails = {
//   name: "Himansu",
//   justDetails: {
//     car: "TATA",
//     school: "Capital school",
//   },
//   fruits: "Mango",
// };

// console.log(myDetails.name);
// console.log(myDetails.justDetails);
// console.log(myDetails.justDetails.car);

// let tiger = {name: 'bengal', eat: 'meat'};
// tiger;
// console.log(tiger.name);
// console.log(tiger.eat);

// let myFood = {name: 'EggRole', taste: 'Yummy', color:'Red & Yello'};
// myFood;
// console.log(myFood.name);
// console.log(myFood.taste);
// console.log(myFood.color);

// Dynamic Typing
// let myString = 'Hello';
// myString;

// let myNumber = '509';
// let yourNumber = "1000";
// let luckyNumber = "9";
// let yourLuckyNumber = "101";

// oops, this is still a string

// console.log(typeof myNumber);
// console.log(typeof yourNumber);
// console.log(typeof luckyNumber);
// console.log(typeof yourLuckyNumber)

// myNumber = 509;
// yourNumber = 1000;
// luckyNumber = 9;
// yourLuckyNumber = 101

// much better - now this is a number

// console.log(typeof myNumber);
// console.log(typeof yourNumber);
// console.log(typeof luckyNumber);
// console.log(typeof yourLuckyNumber);

// Constants in Javascript
//* You must initialize them when you declare them
//* you can't assign them a new value after you've initialized them
//  let count;
//  const count; // error

// let number;
// const number; // error

// let name;
// const name; // error

// let flower;
// const flower; // error

// let count = 1;
// count;
// count = 2;
// count;
// count = 4;
// count;
// count = 0;
// count;
// count = 200;
// count;
// count = 23;
// count;

// const count = 1;
// count = 2 // wrong reassign

// const count = 2;
// count = 3;

// const count = 100;
// count = 23;

// const count = 1023;
// count = 2333;

// but
// const bird = { species: "Kestrel" };
// console.log(bird.species);
// you can add,remove, update like this;
// bird.species = "Striated Caracara";
// console.log(bird.species);

// const flower = {name: "sunflower"};
// console.log(flower.name);
// flower.name = "Suryamukhi";
// console.log(flower.name);

// const myCar = {name: "BMW"};
// myCar.name = "TATA";
// console.log(myCar.name);


// const flower = { name: "tagar" };
// console.log(flower.name);
// flower.name = "Haragaura";
// console.log(flower.name);

// const car = {Name: "maruti", color: "white", model: "23ecd"};
// console.log(car.Name);
// console.log(car.color);
// console.log(car.model);
// car.Name = "Hyundai";
// car.color = "Red";
// car.model = "12ece";
// console.log(car.Name);
// console.log(car.color);
// console.log(car.model);

// When to use const and when to use let
//* details in MDN
